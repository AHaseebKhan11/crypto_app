(function() {
  $(document).on('ready page:load', function() {
    return console.log('asd');
  });

}).call(this);
